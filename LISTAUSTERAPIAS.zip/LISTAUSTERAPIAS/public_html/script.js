/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
document.getElementById('agregarPaciente').addEventListener('click', function() {
    const nombre = document.getElementById('nombre').value;
    const edad = document.getElementById('edad').value;
    const terapia = document.getElementById('terapia').value;

    if (nombre && edad && terapia) {
        const paciente = {
            nombre: nombre,
            edad: edad,
            terapia: terapia
        };

        // Guardar
        let pacientes = JSON.parse(localStorage.getItem('pacientes')) || [];
        pacientes.push(paciente);
        localStorage.setItem('pacientes', JSON.stringify(pacientes));

        // Limpiar campos de entrada
        document.getElementById('nombre').value = '';
        document.getElementById('edad').value = '';
        document.getElementById('terapia').value = '';

        // Actualiza
        listarPacientes();
    } else {
        alert('Por favor, complete todos los campos.');
    }
});

function listarPacientes() {
    const pacientes = JSON.parse(localStorage.getItem('pacientes')) || [];
    const tbody = document.querySelector('#pacientesTable tbody');
    tbody.innerHTML = '';

    pacientes.forEach(function(paciente) {
        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td>${paciente.nombre}</td>
            <td>${paciente.edad}</td>
            <td>${paciente.terapia}</td>
        `;

        tbody.appendChild(tr);
    });
}

// Carga lista 
document.addEventListener('DOMContentLoaded', listarPacientes);


